import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usage-statics',
  templateUrl: './usage-statics.component.html',
  styleUrls: ['./usage-statics.component.css']
})
export class UsageStaticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
