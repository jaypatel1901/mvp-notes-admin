export const constants = {

    // apiBaseURL: 'https://mvp-notes-backend.herokuapp.com/',
    apiBaseURL:'http://localhost:3000/',
    headers: { 'accept': 'application/json', 'content-type': 'application/json' },

};
